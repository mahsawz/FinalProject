import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.org.apache.xml.internal.security.keys.content.KeyValue;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.application.Application;
import javafx.stage.Stage;
import java.io.FileReader;
import java.util.Random;

public class Client extends Application
{


    @Override
    public void start(Stage theStage) throws Exception
    {
        Image image5 = new Image("Ground.jpg");
        ImageView imageView = new ImageView(image5);
        imageView.setFitHeight(660);
        imageView.setFitWidth(660);
        Group root = new Group(imageView);
        Scene scene = new Scene(root,660,660, Color.GREEN);

        MapManager map=new MapManager();
        theStage.setTitle("BomberMan");
        theStage.setScene(scene);
        theStage.show();

        JsonParser parser = new JsonParser();
        FileReader jsonfile = new FileReader("map.json.txt");
        Object obj = parser.parse(jsonfile);
        JsonObject jsonobj = (JsonObject)obj;


        int height = jsonobj.get("height").getAsInt();
        int width=jsonobj.get("width").getAsInt();
        int posyup=jsonobj.get("posyup").getAsInt();
        int posydown=jsonobj.get("posydown").getAsInt();
        int posxleft=jsonobj.get("posxleft").getAsInt();
        int posxright=jsonobj.get("posxright").getAsInt();
        int heightplayer=jsonobj.get("heightplayer").getAsInt();
        int widthplayer=jsonobj.get("widthplayer").getAsInt();
        int heightbomb=jsonobj.get("heightbomb").getAsInt();
        int widthbomb=jsonobj.get("widthbomb").getAsInt();
        int posylock=jsonobj.get("posylock").getAsInt();
        int posxlock=jsonobj.get("posxlock").getAsInt();
        int heightlock=jsonobj.get("heightlock").getAsInt();
        int posxbrick=jsonobj.get("posxbrick").getAsInt();
        int posybrick=jsonobj.get("posybrick").getAsInt();
        int posxbomb=jsonobj.get("posxbomb").getAsInt();
        int posybomb=jsonobj.get("posybomb").getAsInt();





        JsonArray array0 = jsonobj.get("posx").getAsJsonArray();
        JsonArray array1 = jsonobj.get("posy").getAsJsonArray();
        JsonArray array2 = jsonobj.get("posxplayer").getAsJsonArray();
        JsonArray array3 = jsonobj.get("posyplayer").getAsJsonArray();


        //right
        Image image0 = new Image("a1.jpg");
        //left
        Image image3 = new Image("a2.jpg");
        //up
        Image image9 = new Image("a3.jpg");
        //down
        Image image10 = new Image("a4.jpg");
        Image image1 = new Image("b3.jpg");
        Image image2 = new Image("c1.jpg");
        Image image4 = new Image("jon.jpg");
        Image image6 = new Image("bb.jpg");
        Image image7 = new Image("bkb.jpg");
        Image image8 = new Image("bombkh.jpg");




        map.make_wall_up(image2,array0.get(0).getAsInt(),posyup,height,width);
        root.getChildren().addAll(map.deck2);
        Random random=new Random();
       for(int i=0;i<13;i++) {
           boolean flag = random.nextBoolean();

           if (flag == true) {
               int n = random.nextInt(3) + 1;
               switch (n) {
                   case 1:
                       //for(int i=0;i<13;i++){
                       map.make_prize(image4, i, posxbrick, posybrick, heightlock, heightlock);
                       // }

                       break;

                   case 2:
                       //  for(int i=0;i<13;i++){
                       map.make_prize(image7, i, posxbrick, posybrick, heightlock, heightlock);
                       // }
                    //   root.getChildren().addAll(map.deck6);
                       break;

                   case 3:
                       // for(int i=0;i<13;i++){
                       map.make_prize(image8, i, posxbrick, posybrick, heightlock, heightlock);
                       //  }
                    //   root.getChildren().addAll(map.deck6);
                       break;


               }

           }

       }
        root.getChildren().addAll(map.deck6);

        // for(int i=0;i<16;i++)
        // {
        // map.make_wall_up(image4,array0.get(i).getAsInt(),posyup,height,width);
        map.make_wall_left(image2,posxleft,array1.get(0).getAsInt(),height,width);
        map.make_wall_down(image2,array0.get(0).getAsInt(),posydown,height,width);
        map.make_wall_right(image2,posxright,array1.get(0).getAsInt(),height,width);
        //root.getChildren().addAll(map.deck2);
        root.getChildren().addAll(map.deck3);
        root.getChildren().addAll(map.deck4);
        root.getChildren().addAll(map.deck5);
        //}

        for(int i = 0;i < 13; i++)
        {
            map.make_brick(image1,i,posxbrick,posybrick,heightlock,heightlock);
            root.getChildren().addAll(map.deck1);

        }

        map.make_lock1(image2, posxlock, posylock, heightlock, heightlock);
        root.getChildren().addAll(map.deck);



        map.make_player(image0,array2.get(0).getAsInt(),array3.get(0).getAsInt(),widthplayer,heightplayer);
        root.getChildren().addAll(map.imageView1);
        map.make_player(image3,array2.get(1).getAsInt(),array3.get(1).getAsInt(),widthplayer,heightplayer);
        root.getChildren().addAll(map.imageView1);



            map.make_bomb(image6,posxbomb,posybomb , widthbomb, heightbomb);
            root.getChildren().addAll(map.imageView9);


        scene.addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                if(event.getCode()== KeyCode.W){
                    int posx=array2.get(0).getAsInt();
                    int posy=array3.get(0).getAsInt();
                    map.make_player(image8,posx,posy,widthplayer,heightplayer);
                    root.getChildren().addAll(map.imageView1);
                    System.out.println("key that is pressed is "+event.getCode());
                    event.consume();
                }
                if(event.getCode()== KeyCode.S){

                    map.make_player(image0,array2.get(0).getAsInt(),array3.get(0).getAsInt(),widthplayer,heightplayer);
                    root.getChildren().addAll(map.imageView1);
                    map.make_player(image3,array2.get(1).getAsInt(),array3.get(1).getAsInt(),widthplayer,heightplayer);
                    root.getChildren().addAll(map.imageView1);
                    System.out.println("key that is pressed is "+event.getCode());
                    event.consume();
                }
                if(event.getCode()== KeyCode.D){

                    map.make_player(image0,array2.get(0).getAsInt(),array3.get(0).getAsInt(),widthplayer,heightplayer);
                    root.getChildren().addAll(map.imageView1);
                    map.make_player(image3,array2.get(1).getAsInt(),array3.get(1).getAsInt(),widthplayer,heightplayer);
                    root.getChildren().addAll(map.imageView1);

                    System.out.println("key that is pressed is "+event.getCode());
                    event.consume();
                }
                if(event.getCode()== KeyCode.A){

                    map.make_player(image0,array2.get(0).getAsInt(),array3.get(0).getAsInt(),widthplayer,heightplayer);
                    root.getChildren().addAll(map.imageView1);
                    map.make_player(image3,array2.get(1).getAsInt(),array3.get(1).getAsInt(),widthplayer,heightplayer);
                    root.getChildren().addAll(map.imageView1);

                    System.out.println("key that is pressed is "+event.getCode());
                    event.consume();
                }
            }
        });

    }

    public static void main(String args[])
    {
        launch (args);
    }
}
